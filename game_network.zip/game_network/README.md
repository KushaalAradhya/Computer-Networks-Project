# Project 17 – Multiplayer Game Communication Network (UDP + SDN)

| Requirement | Where |
|---|---|
| UDP game-state updates | `game_client.py` sends STATE @20 Hz, `game_server.py` broadcasts SNAPSHOTs |
| Register multiple players | JOIN / JOIN_ACK / JOIN_REJECT (reliable, retry + back-off, max-players) |
| Sequence numbers | per-player STATE seq, global SNAPSHOT seq (both directions) |
| Handle packet loss | gap detection, stale/duplicate discard, dead-reckoning, rejoin, player timeout |
| Traffic prioritization | `game_qos_controller.py` (Ryu) → OVS queue 1 for UDP:5000; clients mark DSCP EF |
| Measure latency | RTT (echo-based) and one-way delay, mean/p50/p95/p99 |
| Measure jitter | RFC 3550 jitter + mean delay variation |
| Test under congestion | `traffic_gen.py` flood; `run_mininet.py` and `test_local.py` |

## Quick test (no root, no Mininet)
    python3 test_local.py            # baseline vs congested-FIFO vs congested-priority + functional tests

## Full SDN run (Ubuntu + Mininet + Open vSwitch + Ryu)
    pip install ryu           # (or os-ken)
    ryu-manager game_qos_controller.py          # terminal 1
    sudo python3 run_mininet.py --duration 20   # terminal 2
Mode file `/tmp/game_qos_mode` = `on` | `off` | `auto` (auto enables priority when a port exceeds 80% of 10 Mbps).
Controller events are logged to `/tmp/game_qos_events.log`.

## Manual run
    python3 game_server.py --port 5000
    python3 game_client.py --server 127.0.0.1:5000 --name alice --duration 30
Note: one-way delay assumes hosts share a clock (true on one machine / Mininet); RTT and jitter do not.
