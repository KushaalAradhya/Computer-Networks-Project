#!/usr/bin/env python3
"""Mininet experiment: 4 players + background-traffic host on s1, game server + sink on s2,
10 Mbps bottleneck between the switches with OVS queues (queue 1 = game).

  Terminal 1:  ryu-manager game_qos_controller.py
  Terminal 2:  sudo python3 run_mininet.py [--duration 20] [--noise-mbps 14] [--cli]

Phases: baseline | congestion, priority OFF | congestion, priority ON | congestion, priority AUTO
"""
import argparse
import json
import os
import time

from mininet.link import Link
from mininet.log import setLogLevel
from mininet.net import Mininet
from mininet.node import RemoteController, OVSSwitch
from mininet.cli import CLI

HERE = os.path.dirname(os.path.abspath(__file__))
MODE_FILE = os.environ.get("GAME_QOS_MODE_FILE", "/tmp/game_qos_mode")
OUT = os.path.join(HERE, "results")
CAP = 10_000_000


def set_qos(sw, intf):
    sw.cmd("ovs-vsctl -- set port %s qos=@q -- --id=@q create qos type=linux-htb other-config:max-rate=%d "
           "queues:0=@q0 queues:1=@q1 -- --id=@q0 create queue other-config:min-rate=1000000 other-config:max-rate=%d "
           "other-config:priority=1 -- --id=@q1 create queue other-config:min-rate=3000000 other-config:max-rate=%d "
           "other-config:priority=0" % (intf, CAP, CAP, CAP))


def build():
    net = Mininet(controller=None, switch=lambda n, **k: OVSSwitch(n, protocols="OpenFlow13", **k), link=Link)
    net.addController("c0", controller=RemoteController, ip="127.0.0.1", port=6653)
    s1, s2 = net.addSwitch("s1"), net.addSwitch("s2")
    players = [net.addHost("p%d" % i) for i in range(1, 5)]
    noise = net.addHost("noise")
    srv, sink = net.addHost("srv"), net.addHost("sink")
    for h in players + [noise]:
        net.addLink(h, s1)
    for h in (srv, sink):
        net.addLink(h, s2)
    net.addLink(s1, s2)
    net.start()
    for a, b in ((s1, s2), (s2, s1)):
        set_qos(a, a.connectionsTo(b)[0][0].name)
    return net, players, noise, srv, sink


def phase(net, players, noise, srv, sink, name, mode, noise_mbps, duration):
    open(MODE_FILE, "w").write(mode)
    time.sleep(3)                                       # let controller poll + flush flows
    print("== %s (mode=%s, noise=%s Mbps)" % (name, mode, noise_mbps), flush=True)
    os.makedirs(OUT, exist_ok=True)
    tag = os.path.join(OUT, name)
    sp = srv.popen("python3 %s/game_server.py --duration %d --out %s_server.json --quiet" % (HERE, duration + 6, tag))
    time.sleep(1)
    procs = []
    if noise_mbps:
        procs.append(sink.popen("python3 %s/traffic_gen.py sink --duration %d" % (HERE, duration + 2)))
        time.sleep(0.5)
        procs.append(noise.popen("python3 %s/traffic_gen.py send --dst %s --mbps %s --duration %d" % (HERE, sink.IP(), noise_mbps, duration)))
    cl = [h.popen("python3 %s/game_client.py --server %s:5000 --name %s --duration %d --out %s_%s.json --quiet" % (
        HERE, srv.IP(), h.name, duration, tag, h.name)) for h in players]
    for p in cl + procs:
        p.wait()
    sp.wait()
    reps = [json.load(open("%s_%s.json" % (tag, h.name))) for h in players if os.path.exists("%s_%s.json" % (tag, h.name))]
    n = max(1, len(reps))
    return {"phase": name, "players": len(reps),
            "rtt_ms": sum(r["rtt_ms"]["mean"] for r in reps) / n, "rtt_p95_ms": sum(r["rtt_ms"]["p95"] for r in reps) / n,
            "jitter_ms": sum(r["jitter_rfc3550_ms"] for r in reps) / n, "loss_pct": sum(r["loss_pct"] for r in reps) / n}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--duration", type=int, default=20)
    ap.add_argument("--noise-mbps", type=float, default=14)
    ap.add_argument("--cli", action="store_true")
    a = ap.parse_args()
    setLogLevel("info")
    net, players, noise, srv, sink = build()
    try:
        time.sleep(2)
        net.ping([players[0], srv])                     # warm up ARP / learning
        if a.cli:
            CLI(net)
            return
        rows = [phase(net, players, noise, srv, sink, n, m, nm, a.duration) for n, m, nm in
                (("baseline", "off", 0), ("congested_no_priority", "off", a.noise_mbps),
                 ("congested_priority", "on", a.noise_mbps), ("congested_auto", "auto", a.noise_mbps))]
        print("\n%-24s %7s %9s %9s %11s %8s" % ("phase", "players", "RTT(ms)", "p95(ms)", "jitter(ms)", "loss%"))
        for r in rows:
            print("%-24s %7d %9.1f %9.1f %11.2f %8.2f" % (r["phase"], r["players"], r["rtt_ms"], r["rtt_p95_ms"], r["jitter_ms"], r["loss_pct"]))
        json.dump(rows, open(os.path.join(OUT, "summary.json"), "w"), indent=2)
    finally:
        net.stop()


if __name__ == "__main__":
    main()
